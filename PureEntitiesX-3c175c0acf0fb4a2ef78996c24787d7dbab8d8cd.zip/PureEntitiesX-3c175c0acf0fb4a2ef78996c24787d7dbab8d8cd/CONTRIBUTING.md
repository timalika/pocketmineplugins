# Contributing to PureEntitiesX 

Please follow Pull Request and Issue Templates when submitting either. That will make it a lot easier and streamline the
process of reviewal and approval.

Issue Reporting Guidelines can be found here:
https://github.com/RevivalPMMP/PureEntitiesX/wiki/Issue-Reporting-Guidelines

Any malicious material submitted that could be used to harm servers will be promptly rejected.
