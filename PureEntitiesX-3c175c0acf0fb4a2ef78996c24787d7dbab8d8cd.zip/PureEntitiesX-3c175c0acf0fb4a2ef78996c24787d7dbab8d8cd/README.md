<img src="https://github.com/RevivalPMMP/PureEntitiesX/blob/master/PureEntitiesXlogo.png?raw=true" alt="PureEntitiesXlogo.png"/>

[![Join the chat at https://gitter.im/RevivalPMMP/PureEntitiesX](https://badges.gitter.im/RevivalPMMP/PureEntitiesX.svg)](https://gitter.im/RevivalPMMP/PureEntitiesX?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
[![Chat](https://img.shields.io/badge/chat-on%20discord-7289da.svg)](https://discord.gg/6Kcx3kK)

[![Poggit-CI](https://poggit.pmmp.io/ci.badge/RevivalPMMP/PureEntitiesX/PureEntitiesX)](https://poggit.pmmp.io/ci/RevivalPMMP/PureEntitiesX/PureEntitiesX)
=====

## Compatible PocketMine-MP Version: https://github.com/pmmp/PocketMine-MP/releases/tag/1.7dev-516

Currently being revived by 95CivicSi - Stay tuned for more updates

PureEntitiesX is currently in Alpha level development while PocketMine-MP works towards reaching a stable API version.  This means that there is no stable release of PureEntitesX and changes are being made very frequently.  Please bear with us as we work towards a complete MobAI solution.  The most reliable versions of PureEntitiesX will be released to Poggit (https://poggit.pmmp.io/p/PureEntitiesX/).  Released versions will be updated to work with released versions of PocketMine-MP (found here: https://github.com/pmmp/PocketMine-MP/releases).  This means that if you are using the latest build of PocketMine-MP from jenkins.pmmp.io or directly from the PocketMine-MP master branch, then PureEntitiesX may not work as those versions are constantly being changed and updated with new items daily (sometimes multiple times per day).

If you are having issues, feel free to report them using the issue template provided.  The more accurate your issue report, the more likely it is that we can help resolve your problem.  If you are not sure about reporting your issue, feel free to connect with us on Gitter (link above).
