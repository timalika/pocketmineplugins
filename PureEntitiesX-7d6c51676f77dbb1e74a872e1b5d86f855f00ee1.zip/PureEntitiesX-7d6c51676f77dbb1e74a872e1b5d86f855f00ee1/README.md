<img src="https://github.com/RevivalPMMP/PureEntitiesX/blob/master/PureEntitiesXlogo.png?raw=true" alt="PureEntitiesXlogo.png"/>

[![Join the chat at https://gitter.im/RevivalPMMP/PureEntitiesX](https://badges.gitter.im/RevivalPMMP/PureEntitiesX.svg)](https://gitter.im/RevivalPMMP/PureEntitiesX?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

[![Poggit-CI](https://poggit.pmmp.io/ci.badge/poggit-orphanage/PureEntitiesX/PureEntitiesX)](https://poggit.pmmp.io/ci/poggit-orphanage/PureEntitiesX/PureEntitiesX)
=====
Currently being revived by 95CivicSi - Stay tuned for more updates
