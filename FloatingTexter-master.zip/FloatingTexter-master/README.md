# FloatingTexter
A PocketMine-MP plugin that lets you create FloatingTexts around the worlds.
