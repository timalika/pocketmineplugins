# RealTime

Extracted plugin from old PocketMine and minor update to work on PMMP

### CREDIT! ###
Extracted plugin from old PocketMine and minor update to work on PMMP. ***Credits - this belongs to Guillaume351 but I couldn't find a git repo to fork from.

### USAGE ###
/hour - get the hour  
/rt  
  enable - enable sync with server time  
  sunrise - set to sunrise  
  sunset - set to sunset  
  day - set to midday  
  night - set to midnight  
  disable - go back to normal pmmp time  
  lock - freeze the time  
