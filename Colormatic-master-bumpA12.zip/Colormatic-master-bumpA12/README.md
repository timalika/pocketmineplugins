# Colormatic
Colormatic: Allows more colors on the server with ease. (Basically, Its mostly to do with changing the color code symbol so something more iconic. ... '&amp;aTest' instead of '§aTest'
