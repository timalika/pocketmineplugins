<?php

declare(strict_types = 1);

namespace BlockHorizons\BlockSniper\events;

use pocketmine\event\plugin\PluginEvent;

abstract class BaseEvent extends PluginEvent {

}
