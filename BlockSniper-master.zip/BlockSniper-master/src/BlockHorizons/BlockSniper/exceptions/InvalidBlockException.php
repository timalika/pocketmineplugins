<?php

declare(strict_types = 1);

namespace BlockHorizons\BlockSniper\exceptions;

class InvalidBlockException extends BlockSniperException {

}