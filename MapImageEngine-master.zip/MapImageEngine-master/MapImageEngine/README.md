# MapImageEngine [![](https://poggit.pmmp.io/shield.state/MapImageEngine)](https://poggit.pmmp.io/p/MapImageEngine)

Plugin that allows you to add full-color images to your server!</br>
Instructions: [click here](https://github.com/FaigerSYS/MapImageEngine/tree/master/MapImageEngine/resources/instructions)!