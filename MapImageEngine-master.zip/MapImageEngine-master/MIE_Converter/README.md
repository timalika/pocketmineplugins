# MIE_Converter ![MIE_Converter](https://poggit.pmmp.io/ci.badge/FaigerSYS/MapImageEngine/MIE_Converter)

This plugin used as offline converter for your images. You can find additional information in the MapImageEngine's instructions