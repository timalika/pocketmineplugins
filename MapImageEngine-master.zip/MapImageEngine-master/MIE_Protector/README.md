# MIE_Protector ![MIE_Protector](https://poggit.pmmp.io/ci.badge/FaigerSYS/MapImageEngine/MIE_Protector)

This plugin used as protection for MapImageEngine images (protection from rotation and destruction)</br>
To bypass protection, player must have **mapimageengine.bypassprotect** permission