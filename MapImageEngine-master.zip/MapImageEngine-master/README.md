### This repository contains some plugins:

Plugin|Description
------|-----------
[MapImageEngine](https://github.com/FaigerSYS/MapImageEngine/tree/master/MapImageEngine)|Image engine for MCPE
MIE_Animations|Animated images (soon)
[MIE_Protector](https://github.com/FaigerSYS/MapImageEngine/tree/master/MIE_Protector)|Addon for MapImageEngine to protect the image (frame) from rotation and destruction
[MIE_Converter](https://github.com/FaigerSYS/MapImageEngine/tree/master/MIE_Converter)|Addon for MapImageEngine to convert images to .mie format

I can not translate the plugin into all languages. I can also have grammatical mistakes in English. So any "language" contribution is welcomed :)
