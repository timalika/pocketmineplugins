<?php

namespace xPaw;

/**
 * Exceptions
 */
class MinecraftQueryException extends \Exception{
	// Exception thrown by MinecraftQuery class
}
