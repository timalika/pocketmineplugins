<?php
namespace Texter\text;

/**
 * CantRemoveFloatingText
 */
class CantRemoveFloatingText extends Text{
  // NOTE: empty
}
