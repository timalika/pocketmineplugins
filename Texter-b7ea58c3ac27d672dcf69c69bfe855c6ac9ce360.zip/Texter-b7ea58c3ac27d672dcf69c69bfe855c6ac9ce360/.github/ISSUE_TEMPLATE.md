### 必須項目 (Required items)
<!--
もし提案などの場合は下の項目は無視して構いません。
If you propose a suggestion, you can ignore the items below.
-->
<!--
サーバー機のOSをご記入ください。例: Win10Home, CentOS6.2...
Please write here your machine OS. example: Win10Home, CentOS6.2 ...
-->
* ServerOS:

<!--
PHPのバージョンをご記入ください。例: php7.0.6 (64bit)
Please write your PHP-version. example: php7.0.9 (64bit)
-->
* PHP version:

<!--
お使いのマインクラフトのバージョンをご記入ください。例: MC:Win10Ed. v1.1.5
Please write the version of Minecraft you are using. example: MC:Win10Ed. v1.1.5
-->
* Minecraft version:

<!--
お使いのTexterのバージョンをご記入ください。 例: Texter v2.2.0
Please write the version of Texter you are using. Example: Texter v 2.2.0
-->
* Texter version:

<!--
問題をできるだけ詳しく以下にご記入ください。
Please report the problem below in detail.
-->
* issue(s):
