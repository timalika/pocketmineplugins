<?php

namespace BlockHorizons\BlockSniper\sessions\owners;

interface ISessionOwner {

}