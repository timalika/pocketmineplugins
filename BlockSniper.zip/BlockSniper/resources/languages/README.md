# Translation information

Thank you for your interest in helping translate.
For an example on how to do it, click the English translation. The English messages are the ones to be translated, so keep those next to you.

Please make sure to end every line with a full stop (.), wherever this is the case in the English translation, and if not, don't.
Please name the file according to the ISO 639-1 codes, which can be found [here](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes).
<br>
It is known there are duplicated translations, but these are for the sole purpose of easier code completion only. Please do feel free to copy those from earlier translations.

### Thank you!
