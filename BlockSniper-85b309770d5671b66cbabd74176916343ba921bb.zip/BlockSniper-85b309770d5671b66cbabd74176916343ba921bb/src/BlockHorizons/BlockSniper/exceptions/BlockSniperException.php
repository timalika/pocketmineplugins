<?php

declare(strict_types = 1);

namespace BlockHorizons\BlockSniper\exceptions;

use pocketmine\plugin\PluginException;

abstract class BlockSniperException extends PluginException {

}