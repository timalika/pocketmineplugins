# Contributing to PureEntitiesX 

Please follow pull request and issue Templates when submitting either. That will make it a lot easier and streamline the
process of reviewal and approval.

Any malicious material submitted that could be used to harm servers will be ppromptly rejected.
