<?php

/**
 * PureEntitiesX: Mob AI Plugin for PMMP
 * Copyright (C)  2018 RevivalPMMP
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


namespace revivalpmmp\pureentities\task;

use pocketmine\level\Position;
use pocketmine\scheduler\PluginTask;
use revivalpmmp\pureentities\PureEntities;
use revivalpmmp\pureentities\PluginConfiguration;
use revivalpmmp\pureentities\task\spawners\animal\ChickenSpawner;
use revivalpmmp\pureentities\task\spawners\animal\CowSpawner;
use revivalpmmp\pureentities\task\spawners\animal\ParrotSpawner;
use revivalpmmp\pureentities\task\spawners\monster\BlazeSpawner;
use revivalpmmp\pureentities\task\spawners\monster\CaveSpiderSpawner;
use revivalpmmp\pureentities\task\spawners\monster\CreeperSpawner;
use revivalpmmp\pureentities\task\spawners\animal\HorseSpawner;
use revivalpmmp\pureentities\task\spawners\animal\OcelotSpawner;
use revivalpmmp\pureentities\task\spawners\animal\PigSpawner;
use revivalpmmp\pureentities\task\spawners\animal\RabbitSpawner;
use revivalpmmp\pureentities\task\spawners\animal\SheepSpawner;
use revivalpmmp\pureentities\task\spawners\monster\EndermanSpawner;
use revivalpmmp\pureentities\task\spawners\monster\GhastSpawner;
use revivalpmmp\pureentities\task\spawners\monster\IronGolemSpawner;
use revivalpmmp\pureentities\task\spawners\monster\MagmaCubeSpawner;
use revivalpmmp\pureentities\task\spawners\monster\PigZombieSpawner;
use revivalpmmp\pureentities\task\spawners\monster\SkeletonSpawner;
use revivalpmmp\pureentities\task\spawners\monster\SlimeSpawner;
use revivalpmmp\pureentities\task\spawners\monster\SpiderSpawner;
use revivalpmmp\pureentities\task\spawners\monster\WolfSpawner;
use revivalpmmp\pureentities\task\spawners\monster\ZombieSpawner;

class AutoSpawnTask extends PluginTask{

	private $plugin;

	/** @var array $spawnerClasses */
	private $spawnerClasses = [];
	/** @var array $spawnerWorlds */
	private $spawnerWorlds = [];

	public function __construct(PureEntities $plugin){
		parent::__construct($plugin);
		$this->plugin = $plugin;
		$this->spawnerWorlds = PluginConfiguration::getInstance()->getEnabledWorlds();
		$this->prepareSpawnerClasses();
	}

	public function onRun(int $currentTick){
		PureEntities::logOutput("AutoSpawnTask: onRun ($currentTick)", PureEntities::DEBUG);

		foreach($this->plugin->getServer()->getLevels() as $level){
			if(count($this->spawnerWorlds) > 0 and !in_array($level->getName(), $this->spawnerWorlds)){
				continue;
			}

			// TODO: Fix inefficiency here.
			// Instead of just running the spawn method for each creature on each player
			// we should build a 'recommended spawn map' based on all active player locations.
			// More notes to come on GitHub project card.

			if(count($level->getPlayers()) > 0){
				foreach($level->getPlayers() as $player){
					foreach($this->spawnerClasses as $spawnerClass){
						$locationValid = false;
						$pass = 1;
						while(!$locationValid){

							$suggestedLocation = PureEntities::getPositionNearPlayer($player);

							// search up and down the current player's y-coordinate to find a valid block!
							$correctedPosition = PureEntities::getSuitableHeightPosition($suggestedLocation->x, $suggestedLocation->y, $suggestedLocation->z, $suggestedLocation->level);
							if($correctedPosition !== null){
								$pos = new Position($correctedPosition->x, $correctedPosition->y - 1, $correctedPosition->z, $level);
								$spawnerClass->spawn($pos, $player);
								$locationValid = true;
							}else{
								PureEntities::logOutput("AutoSpawnTask: suitable spawn coordinate not found.  Pass $pass.", PureEntities::WARN);
								$pass++;
								if($pass >= 300){
									PureEntities::logOutput("AutoSpawnTask: Max number of attempts reached.", PureEntities::WARN);
									break;
								}
							}
						}
					}
				}
			}
		}
	}

	// TODO Automate this to update with a config file or data file.
	private function prepareSpawnerClasses(){
		// $this->spawnerClasses[] = new BatSpawner();
		$this->spawnerClasses[] = new ChickenSpawner();
		$this->spawnerClasses[] = new CowSpawner();
		$this->spawnerClasses[] = new HorseSpawner();
		$this->spawnerClasses[] = new OcelotSpawner();
		// $this->spawnerClasses[] = new ParrotSpawner();
		$this->spawnerClasses[] = new PigSpawner();
		$this->spawnerClasses[] = new RabbitSpawner();
		$this->spawnerClasses[] = new SheepSpawner();

		// monster spawners ...
		$this->spawnerClasses[] = new BlazeSpawner();
		$this->spawnerClasses[] = new CaveSpiderSpawner();
		$this->spawnerClasses[] = new CreeperSpawner();
		$this->spawnerClasses[] = new EndermanSpawner();
		$this->spawnerClasses[] = new GhastSpawner();
		$this->spawnerClasses[] = new IronGolemSpawner();
		$this->spawnerClasses[] = new MagmaCubeSpawner();
		$this->spawnerClasses[] = new PigZombieSpawner();
		$this->spawnerClasses[] = new SkeletonSpawner();
		$this->spawnerClasses[] = new SlimeSpawner();
		$this->spawnerClasses[] = new SpiderSpawner();
		$this->spawnerClasses[] = new WolfSpawner();
		$this->spawnerClasses[] = new ZombieSpawner();

	}

}