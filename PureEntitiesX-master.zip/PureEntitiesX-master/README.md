<img src="https://github.com/RevivalPMMP/PureEntitiesX/blob/master/PureEntitiesXlogo.png?raw=true" alt="PureEntitiesXlogo.png"/>

[![Join the chat at https://gitter.im/RevivalPMMP/PureEntitiesX](https://badges.gitter.im/RevivalPMMP/PureEntitiesX.svg)](https://gitter.im/RevivalPMMP/PureEntitiesX?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

[![Poggit-CI](https://poggit.pmmp.io/ci.badge/RevivalPMMP/PureEntitiesX/PureEntitiesX)](https://poggit.pmmp.io/ci/RevivalPMMP/PureEntitiesX/PureEntitiesX)
=====
Currently being revived by 95CivicSi - Stay tuned for more updates

PureEntitiesX is currently in Alpha level development while PocketMine-MP works towards reaching a stable API version.  This means that there is no stable release of PureEntitesX at the moment and changes are being made very frequently.  Please bear with us as we work towards a complete MobAI solution.

If you are having issues, feel free to report them using the issue template provided.  The more accurate your issue report, the more likely it is that we can help resolve your problem.  If you are not sure about reporting your issue, feel free to connect with us on Gitter (link above).
