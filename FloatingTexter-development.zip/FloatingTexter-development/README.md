# FloatingTexter 
A PocketMine-MP plugin that lets you create FloatingTexts around the worlds. [fycarman](https://github.com/fycarman)

Usage:
/floatingtexter or /ft

/ft add STRING
/ft remove ID
/ft edit ID STRING

Forked to add ypos param for placing the Floating Text at a custom height.

Usage:
/ft add STRING : uses the default ypos set in config.yml 
/ft add INT STRING : textstring at your spawn point at ypos:INT height 
