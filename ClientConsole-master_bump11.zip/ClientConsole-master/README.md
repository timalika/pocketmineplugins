# ClientConsole

A PocketMine-MP plugin to relay console output to clients.